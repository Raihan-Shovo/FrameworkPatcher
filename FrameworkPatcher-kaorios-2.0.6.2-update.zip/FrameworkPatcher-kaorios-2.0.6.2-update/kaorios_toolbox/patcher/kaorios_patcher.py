#!/usr/bin/env python3
"""Kaorios Android 13-17 Auto-Patcher (v2.0.6.2, fail-closed).

Canonical cross-version entry point for Android 13, 14, 15, 16 and 17 smali.
Hook patching is selected by verified class/method layout rather than by blindly
assuming that every OEM ROM of the same Android generation is identical.

Supported targets:
- ActivityThread.smali (process initialization hook)
- ComputerEngine.smali (Hidden App / package visibility filter hook)
- SystemServer.smali (initSystemServer lifecycle hook)
- Instrumentation.smali (context initialization hook)
- Settings$NameValueCache.smali (developer/ADB-status entry guard)
- Build.smali & Build$VERSION.smali (optional Android 17-only Build spoof)
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import importlib.util
import re
import sys
import tempfile
import time
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent


def _unique_label(base: str, method_body: str) -> str:
    """Return base if not already a label in method_body, else base + _<hex4>."""
    candidate = base
    suffix = hashlib.sha256(method_body.encode()).hexdigest()[:4]
    while re.search(rf'(?m)^\s*{re.escape(candidate)}\s*$', method_body):
        candidate = f"{base}_{suffix}"
        suffix = hashlib.sha256((method_body + suffix).encode()).hexdigest()[:4]
    return candidate


def slow_print(text: str, delay: float = 0.01) -> None:
    for line in text.splitlines():
        print(line)
        time.sleep(delay)


def _load_sibling(filename: str, module_name: str):
    target = SCRIPT_DIR / filename
    if target.is_file():
        spec = importlib.util.spec_from_file_location(module_name, target)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod
    return None


mod_at = _load_sibling("patch-activitythread-a17.py", "at_patcher")
mod_ce = _load_sibling("patch-services-a17.py", "ce_patcher")
mod_ss = _load_sibling("patch-systemserver-a17.py", "ss_patcher")

mod_v_fw = _load_sibling("verify-framework-a17-hooks.py", "v_fw")
mod_v_ce = _load_sibling("verify-services-a17-hooks.py", "v_ce")
mod_v_ss = _load_sibling("verify-systemserver-a17-hooks.py", "v_ss")


class PatchStatus:
    PATCHED = "PATCHED"
    ALREADY_PATCHED = "ALREADY_PATCHED"
    UPDATED = "UPDATED"
    UNSUPPORTED_LAYOUT = "UNSUPPORTED_LAYOUT"
    FAILED = "FAILED"
    NOT_TARGET = "NOT_TARGET"


# ==========================================
# CÁC HÀM PATCH KAORIOS HOOK (ANDROID 17)
# ==========================================

def patch_activity_thread(content: str, update: bool = False) -> tuple[str, bool]:
    if mod_at is None:
        raise ValueError("patch-activitythread-a17.py required for ActivityThread patch but unavailable")
    try:
        return mod_at.patch(content, update=update)
    except TypeError:
        return mod_at.patch(content)


def patch_computer_engine(content: str, update: bool = False) -> tuple[str, bool]:
    if mod_ce is not None:
        try:
            return mod_ce.patch(content, update=update)
        except TypeError:
            return mod_ce.patch(content)
    raise ValueError("patch-services-a17.py required for ComputerEngine patch but unavailable")


def patch_system_server(content: str, update: bool = False) -> tuple[str, bool]:
    if mod_ss is None:
        raise ValueError("patch-systemserver-a17.py required for SystemServer patch but unavailable")
    try:
        patched = mod_ss.patch(content, update=update)
    except TypeError:
        patched = mod_ss.patch(content)
    return patched, (patched != content)


def _canonicalize_param_aliases(method_body: str, registers: int, param_count: int) -> str:
    """Replace v(R-P+N) aliases with pN so .registers bump doesn't corrupt them."""
    first_param_v = registers - param_count
    if first_param_v < 0 or registers + 1 > 65535:
        raise ValueError("unsupported register allocation")
    # A range spanning the local/parameter boundary would gain a register after the bump.
    for line in method_body.splitlines():
        instruction = re.sub(r'"(?:\\.|[^"\\])*"|#.*', '', line)
        if '/range' not in instruction:
            continue
        for start, end in re.findall(r'\{\s*v(\d+)\s*\.\.\s*([vp]\d+)\s*\}', instruction):
            if int(start) < first_param_v and (end.startswith('p') or int(end[1:]) >= first_param_v):
                raise ValueError('unsupported register shift: /range crosses local/parameter boundary')
    # Register names inside strings/comments are data and must retain their bytes.
    parts = re.split(r'("(?:\\.|[^"\\])*"|#[^\n]*)', method_body)
    for index in range(0, len(parts), 2):
        for n in range(param_count):
            parts[index] = re.sub(rf'(?<![\w/$;>:])v{first_param_v + n}(?![\w/$;])', f'p{n}', parts[index])
    normalized = ''.join(parts)
    _verify_register_encoding(normalized, registers + 1, param_count)
    return normalized


def _verify_register_encoding(method_body: str, registers: int, param_count: int) -> None:
    """Reject stock operands whose encoding is invalid after a parameter shift."""
    for line in method_body.splitlines():
        instruction = re.sub(r'"(?:\\.|[^"\\])*"|#.*', '', line).strip()
        if not instruction or instruction.startswith(('.', ':')):
            continue
        opcode = instruction.split()[0]
        operands = re.split(r',\s*(?:L|\[)', instruction, maxsplit=1)[0]
        operands = re.sub(r'(?<![\w]):[\w$]+', '', operands)
        names = re.findall(r'\b([vp]\d+)\b', operands)
        narrow = (opcode in ('move', 'move-wide', 'move-object', 'const/4', 'array-length',
                             'rsub-int', 'add-int/lit16', 'and-int/lit16', 'or-int/lit16',
                             'xor-int/lit16',
                             'new-array', 'instance-of', 'if-eq', 'if-ne', 'if-lt',
                             'if-ge', 'if-gt', 'if-le')
                  or opcode.startswith(('iget', 'iput', 'neg-', 'not-'))
                  or '-to-' in opcode or opcode.endswith('/2addr')
                  or (opcode.startswith(('invoke-', 'filled-new-array')) and '/range' not in opcode))
        for index, name in enumerate(names):
            physical = int(name[1:]) + (registers - param_count if name.startswith('p') else 0)
            limit = 15 if narrow else 255
            if opcode.startswith(('invoke-', 'filled-new-array')) and '/range' in opcode or opcode.startswith('move') and opcode.endswith('/16'):
                limit = 65535
            elif opcode.startswith('move') and opcode.endswith('/from16') and index == 1:
                limit = 65535
            if physical > limit:
                raise ValueError(f"unsupported register shift: {opcode} operand {name} becomes v{physical}, encoding limit v{limit}")


def _generator_entry_offset(method_body: str, directive_end: int) -> int:
    """Locate the first instruction after parameter and annotation metadata."""
    offset = directive_end
    annotation_depth = 0
    for line in method_body[directive_end:].splitlines(keepends=True):
        stripped = line.strip()
        if stripped.startswith(('.annotation ', '.subannotation ')):
            annotation_depth += 1
        elif stripped.startswith(('.end annotation', '.end subannotation')):
            annotation_depth -= 1
        elif annotation_depth == 0 and stripped and not stripped.startswith(('#', '.param ', '.end param', '.line ', '.local ', '.end local', '.restart local', '.prologue', '.epilogue')):
            if stripped.startswith('.'):
                raise ValueError(f'unsupported generateKeyPair metadata: {stripped}')
            if stripped.startswith(':'):
                raise ValueError('unsupported generateKeyPair entry label: hook could be bypassed')
            return offset
        offset += len(line)
    raise ValueError('generateKeyPair stock instructions not found')


def _remove_legacy_register_hook(body: str, pattern: re.Pattern, param_count: int) -> str:
    """Remove only a complete block that owns the last allocated local."""
    directive = re.search(r'\.(registers|locals)\s+(\d+)', body)
    blocks = list(pattern.finditer(body))
    if directive is None or len(blocks) != 1 or int(directive[2]) < 1:
        raise ValueError('unsupported update: no single recognized legacy hook block')
    block = blocks[0]
    if block.start() < directive.end():
        raise ValueError('unsupported update: legacy hook precedes register directive')
    registers = re.findall(r'(?m)^\s*(?:move-result-object|move-result|return-object|return|if-eqz)\s+([vp]\d+)', block.group())
    scratch = int(directive[2]) - (param_count if directive[1] == 'registers' else 0) - 1
    if not registers or set(registers) != {f'v{scratch}'}:
        raise ValueError('unsupported update: legacy hook does not own the last local')
    labels = re.findall(r'(?m)^\s*(:[\w$]+)\s*$', block.group())
    branch = re.search(r'if-eqz\s+[vp]\d+,\s*(:[\w$]+)', block.group())
    if len(labels) != 1 or branch is None or branch[1] != labels[0]:
        raise ValueError('unsupported update: unrecognized legacy stock fallback')
    remainder = body[:block.start()] + body[block.end():]
    instructions = re.sub(r'"(?:\\.|[^"\\])*"|#[^\n]*', '', remainder)
    if re.search(re.escape(labels[0]) + r'(?![\w$])', instructions):
        raise ValueError('unsupported update: legacy fallback label is referenced by stock code')
    if re.search(rf'(?<![\w/$;>:])v{scratch}(?![\w/$;])', instructions):
        raise ValueError('unsupported update: legacy scratch is referenced by stock code')
    return (remainder[:directive.start()] + f'.{directive[1]} {int(directive[2]) - 1}'
            + remainder[directive.end():])



def patch_keystore_generator(content: str, update: bool = False) -> tuple[str, bool]:
    start = content.find("generateKeyPair()Ljava/security/KeyPair;")
    if start == -1:
        raise ValueError("generateKeyPair() anchor method not found in KeyPairGeneratorSpi")
    end = content.find('.end method', start)
    if end == -1:
        raise ValueError("unterminated generateKeyPair method in KeyPairGeneratorSpi")

    method_body = content[start:end]
    if "KaoriosHook;->initGenerateSoftwareKeyPair" in method_body:
        try:
            verify_target_content('AndroidKeyStoreKeyPairGeneratorSpi.smali', content)
            return content, False
        except ValueError:
            if not update:
                raise
        hook_re = re.compile(
            r'(?m)^[ \t]*invoke-static(?:/range)?[^\n]*KaoriosHook;->initGenerateSoftwareKeyPair[^\n]*\n'
            r'[ \t]*move-result-object\s+[vp]\d+\n'
            r'(?:\s*\n)*'
            r'[ \t]*if-eqz[^\n]*\n'
            r'[ \t]*return-object\s+[vp]\d+\n'
            r'(?:\s*\n)*'
            r'[ \t]*:cond_kaorios_gen_stock[^\n]*\n?'
        )
        stripped_body = _remove_legacy_register_hook(method_body, hook_re, 1)
        stripped_content = content[:start] + stripped_body + content[end:]
        return patch_keystore_generator(stripped_content, update=False)

    match = re.search(r'\.(registers|locals)\s+(\d+)', method_body)
    if not match:
        raise ValueError(".registers or .locals directive not found in generateKeyPair")

    directive = match.group(1)
    old_reg = int(match.group(2))
    new_reg = old_reg + 1

    if directive == "registers":
        # generateKeyPair() is a virtual (non-static) method with 1 implicit param (p0=this)
        method_body = _canonicalize_param_aliases(method_body, old_reg, 1)
        v_target = f"v{new_reg - 2}"
        p0_num = new_reg - 1
    else:
        method_body = _canonicalize_param_aliases(method_body, old_reg + 1, 1)
        v_target = f"v{old_reg}"
        p0_num = old_reg + 1

    lbl = _unique_label(":cond_kaorios_gen_stock", method_body)
    if p0_num > 15:
        invoke_str = "invoke-static/range {p0 .. p0}, Landroid/security/kaorios/KaoriosHook;->initGenerateSoftwareKeyPair(Ljava/lang/Object;)Ljava/security/KeyPair;"
    else:
        invoke_str = "invoke-static {p0}, Landroid/security/kaorios/KaoriosHook;->initGenerateSoftwareKeyPair(Ljava/lang/Object;)Ljava/security/KeyPair;"

    inject = f"""
    {invoke_str}
    move-result-object {v_target}

    if-eqz {v_target}, {lbl}
    return-object {v_target}

    {lbl}
"""
    entry = _generator_entry_offset(method_body, match.end())
    new_body = (method_body[:match.start()] + f".{directive} {new_reg}"
                + method_body[match.end():entry] + inject + method_body[entry:])
    return content[:start] + new_body + content[end:], True


def _patch_certificate_chain(content: str) -> tuple[str, bool]:
    anchor = re.search(r'(?m)^\.method[^\n]* engineGetCertificateChain\(Ljava/lang/String;\)\[Ljava/security/cert/Certificate;[ \t]*$', content)
    start = anchor.start() if anchor else -1
    if start == -1:
        raise ValueError("engineGetCertificateChain anchor method not found in KeyStoreSpi")
    end = content.find('.end method', start)
    if end == -1:
        raise ValueError("unterminated engineGetCertificateChain method in KeyStoreSpi")

    method_body = content[start:end]
    one_arg = ("Landroid/security/kaorios/KaoriosHook;->CertificateChainIfNeeded"
               "([Ljava/security/cert/Certificate;)[Ljava/security/cert/Certificate;")
    three_arg = ("Landroid/security/kaorios/KaoriosHook;->CertificateChainIfNeeded"
                 "(Ljava/lang/Object;Ljava/lang/String;[Ljava/security/cert/Certificate;)"
                 "[Ljava/security/cert/Certificate;")
    debug_gap = r'(?:\s*\.(?:line|local|end local|restart local|param)[^\n]*\n|\s*\n)*\s*'

    reg_match = re.search(r'\.(registers|locals)\s+(\d+)', method_body)
    if not reg_match:
        raise ValueError("engineGetCertificateChain register directive not found")
    reg_count = int(reg_match.group(2))
    param_base = reg_count - 2 if reg_match.group(1) == "registers" else reg_count
    if param_base + 1 > 15:
        raise ValueError("engineGetCertificateChain: p0/p1 exceed non-range invoke limit")

    def physical(register: str) -> int:
        return param_base + int(register[1:]) if register.startswith('p') else int(register[1:])

    if one_arg in method_body or three_arg in method_body:
        call = re.compile(
            r'(?P<indent>[ \t]*)invoke-static(?:/range)?\s*\{(?P<args>[^}]*)\}\s*,\s*'
            r'Landroid/security/kaorios/KaoriosHook;->CertificateChainIfNeeded'
            r'\([^)]*\)\[Ljava/security/cert/Certificate;')
        calls = list(call.finditer(method_body))
        if len(calls) != 1:
            raise ValueError(
                f"engineGetCertificateChain: expected one covered chain hook, found {len(calls)}")
        match = calls[0]
        args = [item.strip() for item in match.group('args').split(',')]
        if len(args) == 3:
            if args[0] != 'p0' or args[1] != 'p1':
                raise ValueError("engineGetCertificateChain: unexpected three-argument hook registers")
            already = True
        elif len(args) == 1:
            already = False
        else:
            raise ValueError("engineGetCertificateChain: unsupported chain hook registers")
        array = args[-1]
        if not re.fullmatch(r'[vp]\d+', array) or physical(array) > 15:
            raise ValueError("engineGetCertificateChain: chain register exceeds non-range invoke limit")
        # The hook must feed the populated certificate-array return; a historical
        # hook discarded its result, so the move-result target is normalised too.
        pair = re.compile(
            re.escape(f"invoke-static {{p0, p1, {array}}}, {three_arg}")
            + debug_gap + r'move-result-object\s+(?P<result>[vp]\d+)'
            + debug_gap + r'return-object\s+(?P<ret>[vp]\d+)')
        if already:
            found = pair.search(method_body)
            if not found or found.group('ret') != array:
                raise ValueError("engineGetCertificateChain: three-argument hook is not at the return boundary")
            if found.group('result') != array:
                repaired = method_body[:found.start('result')] + array + method_body[found.end('result'):]
                return content[:start] + repaired + content[end:], True
            return content, False
        invoke = f"invoke-static {{p0, p1, {array}}}, {three_arg}"
        new_body = method_body[:match.start()] + match.group('indent') + invoke + method_body[match.end():]
        found = pair.search(new_body)
        if not found or found.group('ret') != array:
            raise ValueError("engineGetCertificateChain: legacy hook does not dominate its return")
        if found.group('result') != array:
            new_body = new_body[:found.start('result')] + array + new_body[found.end('result'):]
        return content[:start] + new_body + content[end:], True

    # The actual A13-A17 methods have two null returns and one populated
    # certificate array return. Match the leaf insertion immediately before
    # that return; a loop's earlier aput-object is not a safe hook point.
    pattern = re.compile(
        r'(?P<aput>aput-object\s+[vp]\d+,\s*(?P<array>[vp]\d+),\s*[vp]\d+)'
        r'(?P<gap>(?:[ \t]*\.(?:line|local|end local|restart local)[^\n]*\n|[ \t]*\n)*)'
        r'[ \t]*(?P<ret>return-object\s+(?P=array))'
    )
    matches = list(pattern.finditer(method_body))
    if not matches:
        raise ValueError("engineGetCertificateChain: leaf-array return not found")
    returns = re.findall(r'\breturn-object\s+([vp]\d+)', method_body)
    if len(returns) == 3 and len(matches) == 1:
        null_reg = returns[0]
        if returns != [null_reg, matches[0].group('array'), null_reg] or not re.search(
            rf'const/4\s+{null_reg},\s*0x0\b', method_body[:matches[0].start()]
        ):
            raise ValueError("engineGetCertificateChain: unsupported null-return layout")
    elif len(returns) != len(matches):
        raise ValueError("engineGetCertificateChain: unsupported return layout")

    new_body = method_body
    for match in reversed(matches):
        array = match.group('array')
        if physical(array) > 15:
            raise ValueError("engineGetCertificateChain: chain register exceeds non-range invoke limit")
        invoke = f"invoke-static {{p0, p1, {array}}}, {three_arg}"
        inject = f"{invoke}\n    move-result-object {array}\n    "
        new_body = new_body[:match.start('ret')] + inject + new_body[match.start('ret'):]
    return content[:start] + new_body + content[end:], True


def patch_keystore_spi(content: str, update: bool = False) -> tuple[str, bool]:
    content, changed = _patch_certificate_chain(content)
    signature = "engineGetCertificate(Ljava/lang/String;)Ljava/security/cert/Certificate;"
    anchor = re.search(r'(?m)^\.method[^\n]* ' + re.escape(signature) + r'[ \t]*$', content)
    start = anchor.start() if anchor else -1
    if start == -1:
        raise ValueError("engineGetCertificate anchor method not found in KeyStoreSpi")
    end = content.find('.end method', start)
    if end == -1:
        raise ValueError("unterminated engineGetCertificate method in KeyStoreSpi")
    body = content[start:end]
    if '->engineGetCertificateChain(Ljava/lang/String;)[Ljava/security/cert/Certificate;' in body:
        verify_target_content('AndroidKeyStoreSpi.smali', content)
        return content, changed
    directive = re.search(r'\.(registers|locals)\s+(\d+)', body)
    if not directive:
        raise ValueError("engineGetCertificate register directive not found")
    locals_count = int(directive.group(2)) - (2 if directive.group(1) == 'registers' else 0)
    if locals_count < 2:
        raise ValueError("engineGetCertificate requires two existing local registers")
    label = _unique_label(':kaorios_certificate_stock', body)
    inject = f"""
    invoke-virtual/range {{p0 .. p1}}, Landroid/security/keystore2/AndroidKeyStoreSpi;->engineGetCertificateChain(Ljava/lang/String;)[Ljava/security/cert/Certificate;
    move-result-object v0
    if-eqz v0, {label}
    array-length v1, v0
    if-eqz v1, {label}
    const/4 v1, 0x0
    aget-object v0, v0, v1
    return-object v0
    {label}
"""
    body = body[:directive.end()] + inject + body[directive.end():]
    return content[:start] + body + content[end:], True


INSTRUMENTATION_HOOK_RE = re.compile(
    r'(?m)^[ \t]*invoke-static(?:/range)?\s*\{p\d+(?:\s*\.\.\s*p\d+)?\},\s*'
    r'Landroid/security/kaorios/KaoriosHook;->initContext\(Landroid/content/Context;\)V[ \t]*(?:#.*)?$'
)
INSTRUMENTATION_RETURN_RE = re.compile(r'(?m)^[ \t]*return-object\s+[vp]\d+')


def patch_instrumentation(content: str, update: bool = False) -> tuple[str, bool]:
    def patch_method(text: str, method_name: str, param: str) -> tuple[str, bool]:
        start = text.find(method_name)
        if start == -1:
            raise ValueError(f"{method_name} anchor method not found in Instrumentation")
        end = text.find('.end method', start)
        if end == -1:
            raise ValueError(f"unterminated {method_name} method in Instrumentation")

        method_body = text[start:end]
        header = text[text.rfind('.method', 0, start):start]
        if "Class;" in method_name and re.search(r'\bstatic\b', header):
            param = "p1"
        if INSTRUMENTATION_HOOK_RE.search(method_body):
            try:
                returns = list(INSTRUMENTATION_RETURN_RE.finditer(method_body))
                hooks = list(INSTRUMENTATION_HOOK_RE.finditer(method_body))
                if not returns or len(returns) != len(hooks):
                    raise ValueError('Instrumentation: incomplete method hook coverage')
                for ret, hook in zip(returns, hooks):
                    args = re.search(r'\{([^}]*)\}', hook.group())[1].replace(' ', '')
                    if args not in (param, f'{param}..{param}') or hook.end() > ret.start() or method_body[hook.end():ret.start()].strip():
                        raise ValueError('Instrumentation: initContext must directly dominate each return')
                return text, False
            except ValueError:
                if not update:
                    raise
            stripped_body = INSTRUMENTATION_HOOK_RE.sub('', method_body)
            clean_text = text[:start] + stripped_body + text[end:]
            patched, _ = patch_method(clean_text, method_name, param)
            return patched, True

        matches = list(re.finditer(r'(return-object\s+[vp]\d+\s*)', method_body))
        if not matches:
            raise ValueError(f"return-object not found in {method_name}")

        reg_match = re.search(r'\.(registers|locals)\s+(\d+)', method_body)
        real_reg_num = 0
        if reg_match:
            directive = reg_match.group(1)
            count = int(reg_match.group(2))
            param_num = int(param[1:])
            if directive == "registers":
                p_count = (2 if param == "p1" else 3) if "Class;" in method_name else 4
                real_reg_num = count - p_count + param_num
            else:
                real_reg_num = count + param_num

        if real_reg_num > 15:
            invoke_str = f"invoke-static/range {{{param} .. {param}}}, Landroid/security/kaorios/KaoriosHook;->initContext(Landroid/content/Context;)V"
        else:
            invoke_str = f"invoke-static {{{param}}}, Landroid/security/kaorios/KaoriosHook;->initContext(Landroid/content/Context;)V"

        # Patch every return path, not just the last one.
        # Work backwards so offsets stay valid.
        new_body = method_body
        for m in reversed(matches):
            inject = f"{invoke_str}\n\n    {m.group(1)}"
            new_body = new_body[:m.start()] + inject + new_body[m.end():]
        return text[:start] + new_body + text[end:], True

    content, c1 = patch_method(content, "newApplication(Ljava/lang/Class;Landroid/content/Context;)Landroid/app/Application;", "p2")
    content, c2 = patch_method(content, "newApplication(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Context;)Landroid/app/Application;", "p3")
    return content, (c1 or c2)


def patch_app_pkg_manager(content: str, update: bool = False) -> tuple[str, bool]:
    pattern = r'(\.method[^\n]*?hasSystemFeature\(Ljava/lang/String;I\)Z.*?\.end method)'
    match = re.search(pattern, content, flags=re.DOTALL)
    if not match:
        raise ValueError("hasSystemFeature(Ljava/lang/String;I)Z method not found in ApplicationPackageManager")

    method_body = match.group(1)
    if "KaoriosHook;->hasSystemFeature" in method_body:
        try:
            verify_target_content('ApplicationPackageManager.smali', content)
            return content, False
        except ValueError:
            if not update:
                raise
        hook_re = re.compile(
            r'(?m)^[ \t]*invoke-static(?:/range)?[^\n]*KaoriosHook;->hasSystemFeature[^\n]*\n'
            r'[ \t]*move-result-object\s+[vp]\d+\n'
            r'(?:\s*\n)*'
            r'[ \t]*if-eqz[^\n]*\n'
            r'[ \t]*invoke-virtual(?:/range)?[^\n]*Boolean;->booleanValue\(\)Z\n'
            r'[ \t]*move-result\s+[vp]\d+\n'
            r'[ \t]*return\s+[vp]\d+\n'
            r'(?:\s*\n)*'
            r'[ \t]*:cond_kaorios_feature_stock[^\n]*\n?'
        )
        stripped_body = _remove_legacy_register_hook(method_body, hook_re, 3)
        stripped_content = content[:match.start()] + stripped_body + content[match.end():]
        return patch_app_pkg_manager(stripped_content, update=False)

    reg_match = re.search(r'\.(registers|locals)\s+(\d+)([^\n]*)', method_body)
    if not reg_match:
        raise ValueError(".registers or .locals directive not found in hasSystemFeature")

    directive = reg_match.group(1)
    old_count = int(reg_match.group(2))
    new_count = old_count + 1

    if directive == "locals":
        # .locals N: locals are v0..v{N-1}; new slot is v{N} (= v{old_count})
        scratch = f"v{old_count}"
        method_body = _canonicalize_param_aliases(method_body, old_count + 3, 3)
        scratch_num = old_count
        p1_num = old_count + 1 + 1 # p0=v{old_count+1}, p1=v{old_count+2}, p2=v{old_count+3}
        p2_num = old_count + 1 + 2
    else:
        # .registers N: total = locals + params; params for instance method with (String;I) = p0,p1,p2 = 3
        # locals = N - 3; new scratch local after bump = v{N - 3} (was v{N-4} before bump)
        param_count = 3  # p0=this, p1=String, p2=int
        method_body = _canonicalize_param_aliases(method_body, old_count, param_count)
        scratch = f"v{new_count - param_count - 1}"
        scratch_num = new_count - param_count - 1
        p1_num = new_count - param_count + 1
        p2_num = new_count - param_count + 2

    new_directive = f".{directive} {new_count}{reg_match.group(3)}"
    lbl = _unique_label(":cond_kaorios_feature_stock", method_body)

    if p1_num > 15 or p2_num > 15:
        invoke_static_str = "invoke-static/range {p1 .. p2}, Landroid/security/kaorios/KaoriosHook;->hasSystemFeature(Ljava/lang/String;I)Ljava/lang/Boolean;"
    else:
        invoke_static_str = "invoke-static {p1, p2}, Landroid/security/kaorios/KaoriosHook;->hasSystemFeature(Ljava/lang/String;I)Ljava/lang/Boolean;"

    if scratch_num > 15:
        invoke_virtual_str = f"invoke-virtual/range {{{scratch} .. {scratch}}}, Ljava/lang/Boolean;->booleanValue()Z"
    else:
        invoke_virtual_str = f"invoke-virtual {{{scratch}}}, Ljava/lang/Boolean;->booleanValue()Z"

    inject = f"""
    {invoke_static_str}
    move-result-object {scratch}

    if-eqz {scratch}, {lbl}
    {invoke_virtual_str}
    move-result {scratch}
    return {scratch}

    {lbl}"""
    new_method = (
        method_body[:reg_match.start()]
        + new_directive
        + inject
        + method_body[reg_match.end():]
    )
    return content[:match.start()] + new_method + content[match.end():], True


NAME_VALUE_METHOD = 'getStringForUser(Landroid/content/ContentResolver;Ljava/lang/String;I)Ljava/lang/String;'
NAME_VALUE_HOOK = ('Landroid/security/kaorios/KaoriosHook;->shouldHideDevStatusFromNameValueCache'
                   '(Landroid/content/ContentResolver;Ljava/lang/String;I)Ljava/lang/String;')


def _name_value_entry(content: str) -> tuple[str, re.Match, int, int]:
    body = _extract_method_body(content, NAME_VALUE_METHOD, 'Settings$NameValueCache')
    header = body.splitlines()[0]
    if re.search(r'\b(static|abstract|native)\b', header):
        raise ValueError('unsupported NameValueCache method flags')
    directive = re.search(r'\.(registers|locals)\s+(\d+)', body)
    if directive is None:
        raise ValueError('NameValueCache register directive not found')
    registers = int(directive[2]) + (4 if directive[1] == 'locals' else 0)
    if not 5 <= registers <= 65535:
        raise ValueError('unsupported NameValueCache register allocation: entry needs a local')
    _verify_register_encoding(body, registers, 4)
    entry = _generator_entry_offset(body, directive.end())
    return body, directive, registers, entry


def patch_name_value_cache(content: str, update: bool = False) -> tuple[str, bool]:
    body, _, _, entry = _name_value_entry(content)
    if 'KaoriosHook;' in body:
        # Partial or foreign hooks are never removed speculatively, even on update.
        verify_target_content('Settings$NameValueCache.smali', content)
        return content, False
    label = _unique_label(':cond_kaorios_settings_stock', body)
    inject = (f'\n    invoke-static/range {{p1 .. p3}}, {NAME_VALUE_HOOK}\n'
              f'    move-result-object v0\n'
              f'    if-eqz v0, {label}\n'
              f'    return-object v0\n\n'
              f'    {label}\n')
    patched = body[:entry] + inject + body[entry:]
    return content.replace(body, patched, 1), True


def patch_build(content: str, update: bool = False) -> tuple[str, bool]:
    fields_null = [
        "BRAND", "BRAND_FOR_ATTESTATION", "DEVICE", "DEVICE_FOR_ATTESTATION",
        "FINGERPRINT", "HARDWARE", "ID", "MANUFACTURER", "MANUFACTURER_FOR_ATTESTATION",
        "MODEL", "MODEL_FOR_ATTESTATION", "PRODUCT", "PRODUCT_FOR_ATTESTATION",
        "TAGS", "TYPE", "USER"
    ]
    anchor = fields_null[0]
    if not re.search(rf'\.field public static[^\n]*? {anchor}:Ljava/lang/String;', content):
        raise ValueError(f"Build.smali: expected field {anchor} not found — unsupported layout")
    if not re.search(r'\.field public static[^\n]*? TIME:J', content):
        raise ValueError("Build.smali: expected field TIME:J not found — unsupported layout")

    patched = content
    for f in fields_null:
        patched = re.sub(rf'(\.field public static[^\n]*?)final([^\n]*? {f}:Ljava/lang/String;)(?:[ \t]*=[^\r\n]*)?', r'\1\2 = null', patched)
        patched = re.sub(rf'(\.field public static[^\n]*? {f}:Ljava/lang/String;)[ \t]*=[^\r\n]*', r'\1 = null', patched)

    patched = re.sub(r'(\.field public static[^\n]*?)final([^\n]*? TIME:J)', r'\1\2', patched)
    return patched, (patched != content)


def patch_build_version(content: str, update: bool = False) -> tuple[str, bool]:
    fields_version = [
        "RELEASE", "RELEASE_OR_CODENAME", "RELEASE_OR_PREVIEW_DISPLAY",
        "SECURITY_PATCH", "DEVICE_INITIAL_SDK_INT"
    ]
    anchor = fields_version[0]
    if not re.search(rf'\.field public static[^\n]*? {anchor}:[^\s]+', content):
        raise ValueError(f"Build$VERSION.smali: expected field {anchor} not found — unsupported layout")

    patched = content
    for f in fields_version:
        patched = re.sub(rf'(\.field public static[^\n]*?)final([^\n]*? {f}:[^\s]+)', r'\1\2', patched)
    return patched, (patched != content)


# ==========================================
# HỆ THỐNG ĐIỀU KHIỂN & VERIFIER
# ==========================================

def get_diff_text(old_text: str, new_text: str, filename: str) -> str:
    diff = difflib.unified_diff(
        old_text.splitlines(), new_text.splitlines(),
        fromfile=f'{filename} (GỐC)', tofile=f'{filename} (ĐÃ PATCH)', lineterm=''
    )
    result = []
    has_diff = False
    for line in diff:
        has_diff = True
        if line.startswith('+') and not line.startswith('+++'): result.append(f"[THÊM] {line[1:]}")
        elif line.startswith('-') and not line.startswith('---'): result.append(f"[XÓA ] {line[1:]}")
        elif line.startswith('@@'): result.append(f"\n--- Vị trí: {line} ---")

    if has_diff:
        return f"\n[{'='*50}]\n CHI TIẾT SỬA ĐỔI FILE: {filename}\n[{'='*50}]\n" + "\n".join(result)
    return ""


def _extract_method_body(content: str, method_anchor: str, label: str) -> str:
    """Return the text of the method containing method_anchor, exclusive of .end method."""
    anchor = re.search(r'(?m)^\.method[^\n]* ' + re.escape(method_anchor) + r'[ \t]*$', content)
    start = anchor.start() if anchor else -1
    if start == -1:
        raise ValueError(f"{label}: method anchor '{method_anchor}' not found")
    end = content.find('.end method', start)
    if end == -1:
        raise ValueError(f"{label}: unterminated method at '{method_anchor}'")
    return content[start:end]


def verify_target_content(filename: str, content: str) -> None:
    """Run dedicated verification on smali content after patch or when already patched."""
    if filename == "ActivityThread.smali":
        if mod_at is not None:
            mod_at.verify(content)
    elif filename == "ComputerEngine.smali":
        if mod_ce is not None:
            mod_ce.verify(content)
    elif filename == "SystemServer.smali":
        if mod_ss is not None:
            mod_ss.verify(content)
    elif filename == "AndroidKeyStoreKeyPairGeneratorSpi.smali":
        body = _extract_method_body(
            content,
            "generateKeyPair()Ljava/security/KeyPair;",
            "AndroidKeyStoreKeyPairGeneratorSpi"
        )
        count = len(re.findall(r'KaoriosHook;->initGenerateSoftwareKeyPair', body))
        if count != 1:
            raise ValueError(
                f"AndroidKeyStoreKeyPairGeneratorSpi: expected exactly 1 initGenerateSoftwareKeyPair hook in generateKeyPair, found {count}"
            )
        directive = re.search(r'\.(registers|locals)\s+(\d+)', body)
        if directive is None:
            raise ValueError("generateKeyPair register directive not found")
        registers = int(directive[2]) + (1 if directive[1] == 'locals' else 0)
        _verify_register_encoding(body, registers, 1)
        entry = _generator_entry_offset(body, directive.end())
        sequence = re.match(
            r'\s*invoke-static(?P<range>/range)?\s*\{p0(?:(?(range)\s*\.\.\s*p0))?\},\s*'
            r'Landroid/security/kaorios/KaoriosHook;->initGenerateSoftwareKeyPair\(Ljava/lang/Object;\)Ljava/security/KeyPair;\s+'
            r'move-result-object\s+(?P<scratch>v\d+)\s+'
            r'if-eqz\s+(?P=scratch),\s*(?P<label>:[\w$]+)\s+'
            r'return-object\s+(?P=scratch)\s*'
            r'(?:\.(?:line|local|end local|restart local)[^\n]*\n|\s)*'
            r'(?P=label)\s*', body[entry:]
        )
        if sequence is None or int(sequence['scratch'][1:]) != registers - 2:
            raise ValueError('generateKeyPair hook must be at entry with a dedicated local and stock fallback')
        label = sequence['label']
        if len(re.findall(rf'(?m)^\s*{re.escape(label)}\s*$', body)) != 1:
            raise ValueError('generateKeyPair stock fallback label is not unique')
        stock_lines = body[entry + sequence.end():].splitlines()
        if not any(re.match(r'^\s*(?:return-object|throw)\b', line) for line in stock_lines):
            raise ValueError('unsupported generateKeyPair stock fallback: no exit')
    elif filename == "AndroidKeyStoreSpi.smali":
        body = _extract_method_body(
            content,
            "engineGetCertificateChain(Ljava/lang/String;)[Ljava/security/cert/Certificate;",
            "AndroidKeyStoreSpi"
        )
        returns = re.findall(r'return-object\s+([vp]\d+)', body)
        return_count = len(returns)
        hook_count = len(re.findall(r'KaoriosHook;->CertificateChainIfNeeded', body))
        if return_count == 0:
            raise ValueError("AndroidKeyStoreSpi: no return-object found in engineGetCertificateChain")
        expected_hooks = 1 if return_count == 3 else return_count
        if hook_count != expected_hooks:
            raise ValueError(
                f"AndroidKeyStoreSpi: expected {expected_hooks} CertificateChainIfNeeded hooks, found {hook_count}"
            )
        if ('Landroid/security/kaorios/KaoriosHook;->CertificateChainIfNeeded'
                '([Ljava/security/cert/Certificate;)[Ljava/security/cert/Certificate;') in body:
            raise ValueError("AndroidKeyStoreSpi: legacy one-argument chain hook must be updated")
        pairs = list(re.finditer(
            r'aput-object\s+[vp]\d+,\s*(?P<array>[vp]\d+),\s*[vp]\d+'
            r'(?:\s*\.(?:line|local|end local|restart local)[^\n]*\n|\s*\n)*\s*'
            r'invoke-static\s*\{p0, p1, (?P=array)\},\s*'
            r'Landroid/security/kaorios/KaoriosHook;->CertificateChainIfNeeded'
            r'\(Ljava/lang/Object;Ljava/lang/String;\[Ljava/security/cert/Certificate;\)\[Ljava/security/cert/Certificate;'
            r'(?:\s*\.(?:line|local|end local|restart local)[^\n]*\n|\s*\n)*\s*'
            r'move-result-object\s+(?P=array)'
            r'(?:\s*\.(?:line|local|end local|restart local)[^\n]*\n|\s*\n)*\s*'
            r'return-object\s+(?P=array)', body
        ))
        if len(pairs) != hook_count:
            raise ValueError("AndroidKeyStoreSpi: dataflow mismatch; hook must directly dominate its return")
        if return_count == 3:
            null_reg = returns[0]
            if returns != [null_reg, pairs[0].group('array'), null_reg] or not re.search(
                rf'const/4\s+{null_reg},\s*0x0\b', body[:pairs[0].start()]
            ):
                raise ValueError("AndroidKeyStoreSpi: unsupported null-return layout")
        elif return_count != hook_count:
            raise ValueError("AndroidKeyStoreSpi: unsupported return layout")
        leaf_body = _extract_method_body(
            content, "engineGetCertificate(Ljava/lang/String;)Ljava/security/cert/Certificate;",
            "AndroidKeyStoreSpi")
        leaf_body = re.sub(r'(?m)^[ \t]*\.(?:line|local|end local|restart local|param)[^\n]*\n', '', leaf_body)
        if not re.search(
            r'invoke-virtual/range \{p0 \.\. p1\}, Landroid/security/keystore2/AndroidKeyStoreSpi;->engineGetCertificateChain'
            r'\(Ljava/lang/String;\)\[Ljava/security/cert/Certificate;\s+'
            r'move-result-object v0\s+if-eqz v0, (?P<label>:[\w]+)\s+'
            r'array-length v1, v0\s+if-eqz v1, (?P=label)\s+'
            r'const/4 v1, 0x0\s+aget-object v0, v0, v1\s+return-object v0\s+(?P=label)', leaf_body):
            raise ValueError("AndroidKeyStoreSpi: single certificate must delegate to the chain with stock fallback")
    elif filename == "Instrumentation.smali":
        body1 = _extract_method_body(
            content,
            "newApplication(Ljava/lang/Class;Landroid/content/Context;)Landroid/app/Application;",
            "Instrumentation"
        )
        body2 = _extract_method_body(
            content,
            "newApplication(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Context;)Landroid/app/Application;",
            "Instrumentation"
        )
        returns1 = len(INSTRUMENTATION_RETURN_RE.findall(body1))
        returns2 = len(INSTRUMENTATION_RETURN_RE.findall(body2))
        hooks1 = len(INSTRUMENTATION_HOOK_RE.findall(body1))
        hooks2 = len(INSTRUMENTATION_HOOK_RE.findall(body2))
        if returns1 > 0 and hooks1 != returns1:
            raise ValueError(
                f"Instrumentation: newApplication(Class,Context) expected {returns1} initContext hooks, found {hooks1}"
            )
        if returns2 > 0 and hooks2 != returns2:
            raise ValueError(
                f"Instrumentation: newApplication(ClassLoader,String,Context) expected {returns2} initContext hooks, found {hooks2}"
            )
        if hooks1 == 0 and hooks2 == 0:
            raise ValueError("Instrumentation: KaoriosHook initContext hook not found in either newApplication method")
        class_header = content[content.rfind('.method', 0, content.find("newApplication(Ljava/lang/Class;Landroid/content/Context;)Landroid/app/Application;")):content.find("newApplication(Ljava/lang/Class;Landroid/content/Context;)Landroid/app/Application;")]
        class_context = 'p1' if re.search(r'\bstatic\b', class_header) else 'p2'
        for body, context_reg in ((body1, class_context), (body2, 'p3')):
            for ret in INSTRUMENTATION_RETURN_RE.finditer(body):
                preceding = body[:ret.start()]
                hook = re.search(
                    rf'(?m)^[ \t]*invoke-static(?:/range)?\s*\{{{context_reg}(?:\s*\.\.\s*{context_reg})?\}},\s*'
                    r'Landroid/security/kaorios/KaoriosHook;->initContext\(Landroid/content/Context;\)V[ \t]*(?:#.*)?\s*\Z',
                    preceding
                )
                if hook is None:
                    raise ValueError("Instrumentation: initContext must directly dominate each return with the Context parameter")
    elif filename == "ApplicationPackageManager.smali":
        pat = re.search(r'(\.method[^\n]*?hasSystemFeature\(Ljava/lang/String;I\)Z.*?\.end method)', content, flags=re.DOTALL)
        if pat is None:
            raise ValueError("ApplicationPackageManager: hasSystemFeature(Ljava/lang/String;I)Z method not found")
        body = pat.group(1)
        directive = re.search(r'\.(registers|locals)\s+(\d+)', body)
        if directive is None:
            raise ValueError("hasSystemFeature register directive not found")
        registers = int(directive[2]) + (3 if directive[1] == 'locals' else 0)
        _verify_register_encoding(body, registers, 3)
        sequence = re.search(
            r'invoke-static(?:/range)?\s*\{p1(?:,\s*p2|\s*\.\.\s*p2)\},\s*'
            r'Landroid/security/kaorios/KaoriosHook;->hasSystemFeature\(Ljava/lang/String;I\)Ljava/lang/Boolean;\s+'
            r'move-result-object\s+(?P<scratch>v\d+)\s+'
            r'if-eqz\s+(?P=scratch),\s*(?P<label>:[\w$]+)\s+'
            r'invoke-virtual(?:/range)?\s*\{(?P=scratch)(?:\s*\.\.\s*(?P=scratch))?\},\s*'
            r'Ljava/lang/Boolean;->booleanValue\(\)Z\s+'
            r'move-result\s+(?P=scratch)\s+'
            r'return\s+(?P=scratch)\s+'
            r'(?:\.line\s+\d+\s+)*'
            r'(?P=label)\b', body
        )
        if sequence is None or body.count('KaoriosHook;->hasSystemFeature') != 1:
            raise ValueError("ApplicationPackageManager: invalid hasSystemFeature hook control flow")
        if len(re.findall(rf'(?m)^\s*{re.escape(sequence.group("label"))}\s*$', body)) != 1:
            raise ValueError("ApplicationPackageManager: stock branch target is not unique")
        prefix = body[:sequence.start()]
        prefix = re.sub(r'(?m)^\s*\.(?:method|registers|locals|param|line)\b[^\n]*$', '', prefix)
        if prefix.strip():
            raise ValueError("ApplicationPackageManager: hook is after stock logic")
    elif filename == 'Settings$NameValueCache.smali':
        body, _, _, entry = _name_value_entry(content)
        sequence = re.match(
            r'\s*invoke-static/range \{p1 \.\. p3\}, ' + re.escape(NAME_VALUE_HOOK) +
            r'\s+move-result-object v0\s+if-eqz v0, (?P<label>:[\w$]+)'
            r'\s+return-object v0\s+(?P=label)\s*', body[entry:])
        if sequence is None or body.count('KaoriosHook;') != 1:
            raise ValueError('NameValueCache: invalid entry hook or incomplete hook coverage')
        label = sequence['label']
        if len(re.findall(rf'(?m)^\s*{re.escape(label)}\s*$', body)) != 1:
            raise ValueError('NameValueCache: stock fallback label is not unique')
        stock = body[entry + sequence.end():]
        if not re.search(r'(?m)^\s*(?:return-object|throw)\b', stock):
            raise ValueError('unsupported NameValueCache stock fallback: no exit')
    elif filename == "Build.smali":
        fields_null = [
            "BRAND", "BRAND_FOR_ATTESTATION", "DEVICE", "DEVICE_FOR_ATTESTATION",
            "FINGERPRINT", "HARDWARE", "ID", "MANUFACTURER", "MANUFACTURER_FOR_ATTESTATION",
            "MODEL", "MODEL_FOR_ATTESTATION", "PRODUCT", "PRODUCT_FOR_ATTESTATION",
            "TAGS", "TYPE", "USER"
        ]
        for f in fields_null:
            m = re.search(rf'\.field public static[^\n]* {f}:Ljava/lang/String;', content)
            if not m:
                if f.endswith("_FOR_ATTESTATION") and not re.search(rf'\.field[^\n]* {f}:', content):
                    continue  # These fields are absent in the included Android 13 sample.
                raise ValueError(f"Build.smali post-patch: field {f} not found")
            if "final" in m.group(0):
                raise ValueError(f"Build.smali post-patch: field {f} still has 'final' modifier — patch did not apply")
            initializer = content[m.end():content.find('\n', m.end()) if '\n' in content[m.end():] else len(content)]
            if initializer.strip() not in ('', '= null'):
                raise ValueError(f"Build.smali post-patch: field {f} must have a null initializer")
        m_time = re.search(r'\.field public static[^\n]* TIME:J', content)
        if not m_time:
            raise ValueError("Build.smali post-patch: field TIME:J not found")
        if "final" in m_time.group(0):
            raise ValueError("Build.smali post-patch: field TIME:J still has 'final' modifier — patch did not apply")
    elif filename == "Build$VERSION.smali":
        fields_version = [
            "RELEASE", "RELEASE_OR_CODENAME", "RELEASE_OR_PREVIEW_DISPLAY",
            "SECURITY_PATCH", "DEVICE_INITIAL_SDK_INT"
        ]
        for f in fields_version:
            m = re.search(rf'\.field public static[^\n]* {f}:[^\s]+', content)
            if not m:
                raise ValueError(f"Build$VERSION.smali post-patch: field {f} not found")
            if "final" in m.group(0):
                raise ValueError(f"Build$VERSION.smali post-patch: field {f} still has 'final' modifier — patch did not apply")


def apply_target_patch(filename: str, content: str, targets: dict, update: bool = False) -> tuple[str, str, str | None]:
    """Execute patch and verification for a target. Returns (status, patched_content, error_message)."""
    patch_fn = targets.get(filename)
    if patch_fn is None:
        return PatchStatus.NOT_TARGET, content, None

    owners = {
        'ActivityThread.smali': 'Landroid/app/ActivityThread;',
        'ComputerEngine.smali': 'Lcom/android/server/pm/ComputerEngine;',
        'SystemServer.smali': 'Lcom/android/server/SystemServer;',
        'AndroidKeyStoreKeyPairGeneratorSpi.smali': 'Landroid/security/keystore2/AndroidKeyStoreKeyPairGeneratorSpi;',
        'AndroidKeyStoreSpi.smali': 'Landroid/security/keystore2/AndroidKeyStoreSpi;',
        'Instrumentation.smali': 'Landroid/app/Instrumentation;',
        'ApplicationPackageManager.smali': 'Landroid/app/ApplicationPackageManager;',
        'Settings$NameValueCache.smali': 'Landroid/provider/Settings$NameValueCache;',
        'Build.smali': 'Landroid/os/Build;',
        'Build$VERSION.smali': 'Landroid/os/Build$VERSION;',
    }
    owner = owners.get(filename)
    declarations = re.findall(r'(?m)^\.class[ \t]+(?:[^\r\n]*?[ \t]+)?(L[^\s;]+;)[ \t]*$', content)
    if owner is None or declarations != [owner]:
        return PatchStatus.UNSUPPORTED_LAYOUT, content, f'{filename}: expected class descriptor {owner}'

    try:
        headers = re.findall(r'(?m)^\.method[^\n]*?\s+([^\s(]+\([^\n]*)$', content)
        if len(headers) != len(set(headers)):
            raise ValueError(f'{filename}: ambiguous duplicate method declaration')
        import inspect
        sig = inspect.signature(patch_fn)
        if 'update' in sig.parameters:
            patched_content, changed = patch_fn(content, update=update)
        else:
            patched_content, changed = patch_fn(content)
        # Verify the content satisfies all hook constraints
        verify_target_content(filename, patched_content)
        if changed:
            return PatchStatus.PATCHED, patched_content, None
        else:
            return PatchStatus.ALREADY_PATCHED, content, None
    except ValueError as e:
        msg = str(e)
        if any(term in msg.lower() for term in ("anchor", "not found", "ambiguous", "unterminated", "unsupported", "missing", "expected exactly one", "found 0")):
            return PatchStatus.UNSUPPORTED_LAYOUT, content, msg
        return PatchStatus.FAILED, content, msg
    except Exception as e:
        return PatchStatus.FAILED, content, str(e)


def run_directory_verifiers(root_path: Path, processed_filenames: set[str]) -> list[str]:
    """Run tree-level verifiers if target components were present in the directory."""
    errors = []
    if "ActivityThread.smali" in processed_filenames and mod_v_fw is not None:
        try:
            mod_at.verify(mod_v_fw.find_activity_thread(root_path).read_bytes().decode('utf-8'))
        except Exception as e:
            errors.append(f"Framework verifier (ActivityThread): {e}")

    if "ComputerEngine.smali" in processed_filenames and mod_v_ce is not None:
        try:
            mod_v_ce.verify_caller(root_path)
        except Exception as e:
            errors.append(f"Services verifier (ComputerEngine): {e}")

    if "SystemServer.smali" in processed_filenames and mod_v_ss is not None:
        try:
            mod_v_ss.verify_caller(root_path)
        except Exception as e:
            errors.append(f"Services verifier (SystemServer): {e}")

    return errors


def _verify_payload_calls(contents: dict[Path, str], payload_smali: str | Path) -> None:
    verifier = _load_sibling('verify-payload-abi.py', 'payload_abi')
    if verifier is None:
        raise ValueError('payload ABI verifier unavailable')
    with tempfile.TemporaryDirectory(prefix='kaorios-abi-') as directory:
        staged_root = Path(directory)
        for relative, content in contents.items():
            staged = staged_root / relative
            staged.parent.mkdir(parents=True, exist_ok=True)
            staged.write_bytes(content.encode('utf-8'))
        payload_root = Path(payload_smali)
        if payload_root.is_file():
            payload_root = payload_root.parent
        verifier.verify_calls(staged_root, payload_root)


def process_files(root_path: str | Path, mode: str, slow: bool = True, update: bool = False,
                  payload_smali: str | Path | None = None) -> bool:
    if payload_smali is None:
        print('[!] Caller-only; payload ABI not verified. Supply --payload-smali to verify compatibility.')
    targets = {}
    if mode in ['1', '3']:
        targets.update({
            "ActivityThread.smali": patch_activity_thread,
            "ComputerEngine.smali": patch_computer_engine,
            "SystemServer.smali": patch_system_server,
            "AndroidKeyStoreKeyPairGeneratorSpi.smali": patch_keystore_generator,
            "AndroidKeyStoreSpi.smali": patch_keystore_spi,
            "ApplicationPackageManager.smali": patch_app_pkg_manager,
            "Instrumentation.smali": patch_instrumentation,
            "Settings$NameValueCache.smali": patch_name_value_cache,
        })
    if mode in ['2', '3']:
        targets.update({
            "Build.smali": patch_build,
            "Build$VERSION.smali": patch_build_version
        })

    p = Path(root_path)

    if p.is_symlink():
        print('[!] Unsupported layout: symbolic-link target.')
        return False

    # Single file target
    if p.is_file():
        file = p.name
        if file not in targets:
            print(f"[-] {file} không nằm trong danh sách mục tiêu patch của mode {mode}.")
            return False

        content = p.read_bytes().decode("utf-8")
        status, patched_content, err_msg = apply_target_patch(file, content, targets, update=update)
        if payload_smali is not None and status in (PatchStatus.PATCHED, PatchStatus.ALREADY_PATCHED):
            try:
                _verify_payload_calls({Path(file): patched_content}, payload_smali)
            except ValueError as error:
                print(f'[!] Payload ABI verification failed: {error}')
                return False

        if status == PatchStatus.PATCHED:
            diff_output = get_diff_text(content, patched_content, file)
            if slow:
                slow_print(diff_output, delay=0.01)
            else:
                print(diff_output)
            p.write_bytes(patched_content.encode("utf-8"))
            print(f"    [+] ĐÃ TỰ ĐỘNG LƯU: {file} (Status: {status})\n")
            return True
        elif status == PatchStatus.ALREADY_PATCHED:
            if update:
                p.write_bytes(patched_content.encode("utf-8"))
                print(f"    [+] ĐÃ CẬP NHẬT (UPDATE): {file} (Verifier PASS).\n")
            else:
                print(f"    [=] {file}: ĐÃ ĐƯỢC PATCH TỪ TRƯỚC (Verifier PASS).\n")
            return True
        elif status == PatchStatus.UNSUPPORTED_LAYOUT:
            print(f"    [!] {file}: BỐ CỤC KHÔNG HỖ TRỢ (UNSUPPORTED LAYOUT): {err_msg}\n")
            return False
        else:
            print(f"    [!] {file}: THẤT BẠI (FAILED): {err_msg}\n")
            return False

    if not p.is_dir():
        print(f"[!] Đường dẫn không tồn tại: {p.resolve()}")
        return False

    print(f"\n[*] Đang quét tự động tại thư mục: {p.resolve()} ...")
    if slow:
        time.sleep(0.3)

    candidates = sorted(path for path in p.rglob('*.smali') if path.name in targets)
    names = [path.name for path in candidates]
    if len(names) != len(set(names)):
        print('[!] Unsupported layout: ambiguous duplicate target filenames.')
        return False
    if any(path.is_symlink() for path in candidates):
        print('[!] Unsupported layout: symbolic-link target.')
        return False

    # Validate all content and tree-level target locations before touching originals.
    planned = {}
    with tempfile.TemporaryDirectory(prefix='kaorios-preflight-') as directory:
        staged_root = Path(directory)
        for path in candidates:
            content = path.read_bytes().decode('utf-8')
            result = apply_target_patch(path.name, content, targets, update=update)
            status, patched_content, error = result
            if status not in (PatchStatus.PATCHED, PatchStatus.ALREADY_PATCHED):
                print(f'[!] {path.name}: {status}: {error}')
                return False
            planned[path] = (content, result)
            staged = staged_root / path.relative_to(p)
            staged.parent.mkdir(parents=True, exist_ok=True)
            staged.write_bytes(patched_content.encode('utf-8'))
        if payload_smali is not None:
            verifier = _load_sibling('verify-payload-abi.py', 'payload_abi')
            try:
                if verifier is None:
                    raise ValueError('payload ABI verifier unavailable')
                verifier.verify_calls(staged_root, Path(payload_smali))
            except ValueError as error:
                print(f'[!] Payload ABI verification failed: {error}')
                return False
        tree_errors = run_directory_verifiers(staged_root, set(names))
        if tree_errors:
            for error in tree_errors:
                print(f'[!] {error}')
            return False
    # Also reject concurrent changes between preflight and publication.
    if any(path.read_bytes() != content.encode('utf-8') for path, (content, _) in planned.items()):
        print('[!] Target changed during preflight; no files written.')
        return False

    processed_targets: set[str] = set()
    patched_count = 0
    already_patched_count = 0
    updated_count = 0
    unsupported_count = 0
    failed_count = 0

    for filepath, (content, (status, patched_content, err_msg)) in planned.items():
        file = filepath.name
        processed_targets.add(file)
        if status == PatchStatus.PATCHED:
            diff_output = get_diff_text(content, patched_content, file)
            if slow:
                slow_print(diff_output, delay=0.01)
            else:
                print(diff_output)
            filepath.write_bytes(patched_content.encode("utf-8"))
            print(f"    [+] ĐÃ TỰ ĐỘNG LƯU: {file} (Status: {status})\n")
            patched_count += 1
            if slow:
                time.sleep(0.1)
        elif status == PatchStatus.ALREADY_PATCHED:
            if update:
                filepath.write_bytes(patched_content.encode("utf-8"))
                print(f"    [+] ĐÃ CẬP NHẬT (UPDATE): {file} (Verifier PASS).\n")
                updated_count += 1
            else:
                print(f"    [=] {file}: ĐÃ ĐƯỢC PATCH TỪ TRƯỚC (Verifier PASS).\n")
                already_patched_count += 1

    total_processed = patched_count + already_patched_count + updated_count + unsupported_count + failed_count
    if total_processed == 0:
        print("[-] Không tìm thấy file mục tiêu nào trong thư mục.")
        return False

    # If any target encountered error or unsupported layout, fail closed
    if failed_count > 0 or unsupported_count > 0:
        print(f"\n[!] THẤT BẠI: Có {failed_count + unsupported_count} file gặp lỗi / unsupported layout.")
        return False

    summary_details = f"{patched_count} đã patch"
    if updated_count > 0:
        summary_details += f", {updated_count} đã cập nhật"
    if already_patched_count > 0:
        summary_details += f", {already_patched_count} đã patch từ trước"
    print(f"\n[+] HOÀN TẤT: Đã xử lý {total_processed} file mục tiêu ({summary_details}). Tất cả verifier đều PASS.")
    return True


def main() -> None:
    parser = argparse.ArgumentParser(description="Kaorios Android 13-17 Auto-Patcher")
    parser.add_argument("path", nargs="?", default=None, help="Directory or smali file to patch")
    parser.add_argument("--mode", choices=["1", "2", "3"], default=None, help="1=Hooks (A13-A17), 2=Build Spoof (A17 only), 3=Hooks + Build Spoof (A17 only)")
    parser.add_argument("--android-version", choices=["13", "14", "15", "16", "17"], default=None,
                        help="Target Android generation. Required for documented usage; mode 2/3 only support 17.")
    parser.add_argument("--update", "-u", action="store_true", help="Update and rewrite targets even if already patched (Verifier PASS)")
    parser.add_argument("--no-delay", action="store_true", help="Disable output animation delays")
    parser.add_argument("--payload-smali", type=Path, help="Disassembled payload to verify facade ABI before writing")
    args = parser.parse_args()

    # Non-interactive CLI mode. Keep omitted --android-version compatible with
    # older automation, but documented invocations must pass it explicitly.
    if args.path is not None and args.mode is not None:
        if args.android_version is not None and args.mode in ("2", "3") and args.android_version != "17":
            parser.error("mode 2/3 contains the Android 17-only Build spoof; use mode 1 on Android 13-16")
        if args.android_version is None:
            print("[!] --android-version not supplied; using layout detection only (legacy compatibility).")
        else:
            print(f"[*] Target Android {args.android_version}; hooks remain verifier/layout driven.")
        success = process_files(args.path, args.mode, slow=not args.no_delay, update=args.update,
                                payload_smali=args.payload_smali)
        sys.exit(0 if success else 1)

    # Interactive mode
    print("========================================")
    print("   KAORIOS PATCHER — ANDROID 13 → 17")
    print("========================================")
    print("  [1]. Patch Kaorios Hooks (Android 13-17; layout verified)")
    print("  [2]. Patch Build Spoof (Android 17 only)")
    print("  [3]. Hooks + Build Spoof (Android 17 only)")

    try:
        android_version = args.android_version
        if android_version is None:
            android_version = input("\n-> Android version (13/14/15/16/17): ").strip()
        if android_version not in ("13", "14", "15", "16", "17"):
            print("Android version không hợp lệ!")
            sys.exit(1)

        mode = args.mode
        if mode is None:
            mode = input("-> Nhập lựa chọn (1/2/3): ").strip()
        if mode not in ['1', '2', '3']:
            print("Lựa chọn không hợp lệ!")
            sys.exit(1)
        if mode in ("2", "3") and android_version != "17":
            print("Mode 2/3 có Build spoof riêng Android 17. Android 13-16 dùng mode 1.")
            sys.exit(1)

        update = args.update
        if not update:
            update_choice = input("-> Cho phép update/ghi đè nếu đã patch từ trước? (y/N): ").strip().lower()
            update = update_choice in ("y", "yes")

        target_dir = args.path
        if target_dir is None:
            target_dir = input("-> Nhập đường dẫn thư mục smali (nhấn Enter để dùng thư mục hiện tại): ").strip()
            if not target_dir:
                target_dir = str(SCRIPT_DIR)

        success = process_files(target_dir, mode, slow=not args.no_delay, update=update,
                                payload_smali=args.payload_smali)
        if not success:
            sys.exit(1)
    except Exception as e:
        print(f"\n[!] LỖI TOOL: {e}")
        sys.exit(1)

    print("\n" + "="*40)
    if sys.stdin.isatty():
        input(">>> NHẤN ENTER ĐỂ TẮT TOOL <<<")


if __name__ == "__main__":
    main()
