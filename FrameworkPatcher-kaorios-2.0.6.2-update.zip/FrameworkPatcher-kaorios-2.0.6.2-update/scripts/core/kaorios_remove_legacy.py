#!/usr/bin/env python3
"""Remove the OLD Kaorios patch (V1.x / 2.0.4.0 era) from a decompiled framework tree.

The old patch did exactly these things, and this script undoes exactly these things:
  1. copied utility classes into  com/android/internal/util/kaorios/        -> directory is deleted
  2. Instrumentation.newApplication x2: invoke-static KaoriPropsUtils;->KaoriProps       -> line removed
  3. KeyStore2.getKeyEntry:             invoke-static KaoriKeyboxHooks;->KaoriGetKeyEntry (+ move-result) -> removed
  4. AndroidKeyStoreSpi.engineGetCertificateChain:
        invoke-static KaoriPropsUtils;->KaoriGetCertificateChain()V                         -> removed
        invoke-static KaoriKeyboxHooks;->KaoriGetCertificateChain(...) (+ move-result)      -> removed
  5. ApplicationPackageManager.hasSystemFeature(String,int): the KaoriFeatureOverrides block
        (from the currentPackageName() call up to :cond_kaori_override)                     -> removed

Fail-closed: if ANY reference to com/android/internal/util/kaorios survives, the script exits 1.
A jar that does not carry the old patch is left untouched (exit 0).

Usage: kaorios_remove_legacy.py <framework_decompile_dir> [--check]
  --check : only report whether the old patch is present (exit 10 = present, 0 = clean)
"""
from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

OLD_PKG = "Lcom/android/internal/util/kaorios/"
OLD_DIR = ("com", "android", "internal", "util", "kaorios")


def smali_files(root: Path):
    return sorted(root.rglob("*.smali"))


def find_old_dirs(root: Path) -> list[Path]:
    return [p for p in root.rglob("kaorios")
            if p.is_dir() and tuple(p.parts[-5:]) == OLD_DIR]


def referencing_files(root: Path) -> list[Path]:
    hits = []
    for path in smali_files(root):
        if OLD_DIR[-1] in path.parts and "util" in path.parts:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if OLD_PKG in text:
            hits.append(path)
    return hits


def strip_invoke_with_move_result(lines: list[str]) -> tuple[list[str], int]:
    """Remove `invoke-static ... Lcom/android/internal/util/kaorios/...` and the move-result right after it."""
    out, removed, i = [], 0, 0
    while i < len(lines):
        line = lines[i]
        if OLD_PKG in line and line.strip().startswith("invoke-static"):
            removed += 1
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            if j < len(lines) and lines[j].strip().startswith("move-result"):
                i = j + 1
            else:
                i += 1
            continue
        out.append(line)
        i += 1
    return out, removed


def _prev_code(lines: list[str], idx: int) -> int:
    """Index of the previous non-blank line before idx (or -1)."""
    k = idx - 1
    while k >= 0 and not lines[k].strip():
        k -= 1
    return k


def _next_code(lines: list[str], idx: int) -> int:
    """Index of the next non-blank line after idx (or len(lines))."""
    k = idx + 1
    while k < len(lines) and not lines[k].strip():
        k += 1
    return k


def _bad_layout(where: str) -> "SystemExit":
    return SystemExit(f"[!] ApplicationPackageManager: unexpected layout ({where}); refusing to guess. "
                      "Use a stock framework.jar.")


def strip_feature_override_block(lines: list[str]) -> tuple[list[str], int]:
    """Remove the ApplicationPackageManager.hasSystemFeature(String,int) KaoriFeatureOverrides hook.

    Two shapes exist in the wild and both are handled:
      A) labelled (written by the old patcher itself): ... :try_start_kaori_override ... :cond_kaori_override
      B) recompiled (labels renamed, e.g. :cond_0, no try/catch):
             invoke-static {}, ActivityThread;->currentPackageName()
             move-result-object v0
             iget-object v1, p0, ApplicationPackageManager;->mContext
             invoke-static {v1, p1, v0}, KaoriFeatureOverrides;->getOverride(...)
             move-result-object v0
             if-eqz v0, :LABEL
             invoke-virtual {v0}, Boolean;->booleanValue()Z
             move-result p0
             return p0
    Everything up to and including `return p0` (shape B) / :cond_kaori_override (shape A) is removed.
    """
    # ---- shape A ----
    try:
        start_label = next(i for i, l in enumerate(lines) if l.strip() == ":try_start_kaori_override")
        end_label = next(i for i, l in enumerate(lines) if l.strip() == ":cond_kaori_override")
    except StopIteration:
        start_label = end_label = None
    if start_label is not None:
        if end_label < start_label:
            raise _bad_layout("label order")
        second = _prev_code(lines, start_label)
        first = _prev_code(lines, second) if second >= 0 else -1
        if (first < 0
                or not lines[second].strip().startswith("move-result-object")
                or "ActivityThread;->currentPackageName()" not in lines[first]):
            raise _bad_layout("before :try_start_kaori_override")
        return lines[:first] + lines[end_label + 1:], 1

    # ---- shape B ----
    hook = [i for i, l in enumerate(lines) if "KaoriFeatureOverrides;->getOverride" in l]
    if not hook:
        return lines, 0
    if len(hook) != 1:
        raise _bad_layout("several getOverride calls")
    h = hook[0]

    # backwards: iget-object mContext, move-result-object v0, invoke-static currentPackageName()
    i_iget = _prev_code(lines, h)
    i_mr = _prev_code(lines, i_iget) if i_iget >= 0 else -1
    i_cur = _prev_code(lines, i_mr) if i_mr >= 0 else -1
    if (i_cur < 0
            or not re.match(r"\s*iget-object v1, p0, Landroid/app/ApplicationPackageManager;->mContext:", lines[i_iget])
            or lines[i_mr].strip() != "move-result-object v0"
            or lines[i_cur].strip() != "invoke-static {}, Landroid/app/ActivityThread;->currentPackageName()Ljava/lang/String;"):
        raise _bad_layout("lines before getOverride")

    # forwards: move-result-object v0, if-eqz v0, :L, invoke-virtual booleanValue, move-result p0, return p0
    expected = [
        lambda t: t == "move-result-object v0",
        lambda t: re.fullmatch(r"if-eqz v0, :[A-Za-z0-9_]+", t) is not None,
        lambda t: t == "invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z",
        lambda t: t == "move-result p0",
        lambda t: t == "return p0",
    ]
    k, last = h, h
    for check in expected:
        k = _next_code(lines, k)
        if k >= len(lines) or not check(lines[k].strip()):
            raise _bad_layout("lines after getOverride")
        last = k
    return lines[:i_cur] + lines[last + 1:], 1


def process_file(path: Path) -> int:
    original = path.read_text(encoding="utf-8")
    lines = original.splitlines()
    changed = 0

    if path.name == "ApplicationPackageManager.smali":
        lines, n = strip_feature_override_block(lines)
        changed += n
    lines, n = strip_invoke_with_move_result(lines)
    changed += n

    if changed:
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return changed


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    check_only = "--check" in sys.argv
    if len(args) != 1:
        print(__doc__)
        return 2
    root = Path(args[0])
    if not root.is_dir():
        print(f"[!] Not a directory: {root}")
        return 2

    old_dirs = find_old_dirs(root)
    refs = referencing_files(root)
    present = bool(old_dirs or refs)

    if check_only:
        return 10 if present else 0
    if not present:
        print("[=] No old Kaorios patch found - nothing to remove")
        return 0

    print("[*] Old Kaorios patch detected - removing it")
    total = 0
    for path in refs:
        n = process_file(path)
        total += n
        print(f"    - {path.relative_to(root)}: {n} hook change(s) removed")

    removed_classes = 0
    for directory in old_dirs:
        removed_classes += sum(1 for _ in directory.rglob("*.smali"))
        shutil.rmtree(directory)
        print(f"    - deleted {directory.relative_to(root)}")

    # Fail closed: nothing may still point at the old package.
    leftovers = referencing_files(root)
    leftover_dirs = find_old_dirs(root)
    if leftovers or leftover_dirs:
        print("[!] Old Kaorios references are still present - the jar differs from the known old patch:")
        for path in leftovers[:20]:
            print(f"      {path.relative_to(root)}")
        print("    Nothing is safe to patch on top of this. Use a stock framework.jar.")
        return 1

    print(f"[+] Old Kaorios removed: {removed_classes} utility class(es), {total} hook change(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
