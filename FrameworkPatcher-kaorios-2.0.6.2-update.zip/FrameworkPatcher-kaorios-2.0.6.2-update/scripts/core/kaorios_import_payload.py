#!/usr/bin/env python3
"""Import the Kaorios payload (disassembled classes.dex) into a decompiled framework tree.

Rules (from the Kaorios 2.0.6.2 patcher README):
  * import class-wise, never overwrite a whole DEX / delete a namespace;
  * a payload class that already exists in the framework replaces ONLY that exact class,
    in the smali directory that already owns it (one owner per class);
  * a payload class that is NEW goes into its own fresh DEX split (smali_classes<N+1>), so a
    nearly-full last split of the ROM can never overflow the 65,535 index limit;
  * unrelated OEM classes (even in the same package) are never touched.

Usage: kaorios_import_payload.py <framework_decompile_dir> <payload_smali_root>
"""
from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path


def smali_dirs(root: Path) -> list[Path]:
    """Return smali, smali_classes2, smali_classes3 ... sorted by split number."""
    found = []
    for child in root.iterdir():
        match = re.fullmatch(r"smali(?:_classes(\d+))?", child.name)
        if child.is_dir() and match:
            found.append((int(match.group(1) or 1), child))
    return [path for _, path in sorted(found)]


def payload_smali_dirs(payload_root: Path) -> list[Path]:
    dirs = smali_dirs(payload_root)
    if not dirs:
        raise SystemExit(f"[!] No smali directory found in payload root: {payload_root}")
    return dirs


def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 2

    target_root = Path(sys.argv[1])
    payload_root = Path(sys.argv[2])
    target_dirs = smali_dirs(target_root)
    if not target_dirs:
        print(f"[!] No smali directory found in: {target_root}")
        return 1
    # New classes get their own split. Re-runs find the payload classes already owned by that
    # split and simply replace them in place, so the operation is idempotent.
    last_number = max(
        int((re.fullmatch(r"smali(?:_classes(\d+))?", d.name).group(1)) or 1) for d in target_dirs
    )
    new_split = target_root / f"smali_classes{last_number + 1}"

    replaced, added = 0, 0
    for src_dir in payload_smali_dirs(payload_root):
        for src in sorted(src_dir.rglob("*.smali")):
            rel = src.relative_to(src_dir)
            owners = [d for d in target_dirs if (d / rel).is_file()]
            if len(owners) > 1:
                print(f"[!] {rel} already exists in several DEX splits "
                      f"({', '.join(d.name for d in owners)}); refusing to guess the owner.")
                return 1
            if owners:
                destination = owners[0] / rel
                replaced += 1
            else:
                destination = new_split / rel
                added += 1
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, destination)

    print(f"[+] Payload imported: {added} new class(es) into {new_split.name}, "
          f"{replaced} existing class(es) replaced in place")
    if added + replaced == 0:
        print("[!] Payload contained no classes")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
