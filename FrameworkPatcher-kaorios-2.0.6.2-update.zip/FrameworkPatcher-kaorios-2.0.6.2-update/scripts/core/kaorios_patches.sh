#!/usr/bin/env bash
# kaorios_patches.sh - Kaorios Toolbox 2.0.6.x framework + services patching
#
# How it works (replaces the old V1.x "utility smali classes" approach):
#   1. The Kaorios payload (kaorios_toolbox/payload/classes.dex) is disassembled and its
#      classes are imported class-wise into framework.jar  (android.security.kaorios.KaoriosHook ...).
#   2. The OFFICIAL Kaorios patcher (kaorios_toolbox/patcher/kaorios_patcher.py, vendored
#      unchanged from the Kaorios-Toolbox repo) inserts the call-site hooks:
#        framework.jar : Instrumentation, ActivityThread, Settings$NameValueCache,
#                        ApplicationPackageManager, AndroidKeyStoreKeyPairGeneratorSpi,
#                        AndroidKeyStoreSpi
#        services.jar  : SystemServer, ComputerEngine
#   3. The payload ABI verifier checks every KaoriosHook call against the payload.
#
# Jars that still carry an OLD Kaorios patch (1.x / 2.0.4.0) are cleaned automatically first
# (scripts/core/kaorios_remove_legacy.py); anything it cannot remove cleanly aborts the run.

_KAORIOS_SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_KAORIOS_REPO_ROOT="$(cd "${_KAORIOS_SELF_DIR}/../.." && pwd)"
KAORIOS_ASSET_DIR="${_KAORIOS_REPO_ROOT}/kaorios_toolbox"
KAORIOS_PATCHER="${KAORIOS_ASSET_DIR}/patcher/kaorios_patcher.py"
KAORIOS_VERIFY_ABI="${KAORIOS_ASSET_DIR}/patcher/verify-payload-abi.py"
KAORIOS_PAYLOAD_DEX="${KAORIOS_ASSET_DIR}/payload/classes.dex"
KAORIOS_PAYLOAD_SHA="${KAORIOS_ASSET_DIR}/payload/classes.dex.sha256"
KAORIOS_PAYLOAD_SMALI=""   # filled by kaorios_prepare_payload

# Disassemble the payload once per run (verifying its SHA-256 first).
kaorios_prepare_payload() {
    [ -n "$KAORIOS_PAYLOAD_SMALI" ] && [ -d "$KAORIOS_PAYLOAD_SMALI" ] && return 0

    local tools_dir="${TOOLS_DIR:-$(pwd)/tools}"
    local work_dir="${WORK_DIR:-$(pwd)}"

    for f in "$KAORIOS_PATCHER" "$KAORIOS_VERIFY_ABI" "$KAORIOS_PAYLOAD_DEX" "$KAORIOS_PAYLOAD_SHA"; do
        if [ ! -f "$f" ]; then
            err "Kaorios asset missing: $f"
            return 1
        fi
    done
    command -v python3 >/dev/null 2>&1 || { err "python3 not found (required by the Kaorios patcher)"; return 1; }
    command -v zip >/dev/null 2>&1 || { err "zip not found (needed to wrap the payload for apktool)"; return 1; }

    local expected actual
    expected="$(awk '{print $1}' "$KAORIOS_PAYLOAD_SHA" | head -n1)"
    actual="$(sha256sum "$KAORIOS_PAYLOAD_DEX" | awk '{print $1}')"
    if [ "$expected" != "$actual" ]; then
        err "Kaorios payload checksum mismatch (expected $expected, got $actual)"
        return 1
    fi

    local payload_work="${work_dir}/kaorios_payload_work"
    rm -rf "$payload_work"
    mkdir -p "$payload_work"
    # apktool can only open apk/jar files, so wrap the dex in a throw-away jar.
    cp "$KAORIOS_PAYLOAD_DEX" "$payload_work/classes.dex"
    (cd "$payload_work" && zip -q payload.jar classes.dex) || { err "Failed to wrap payload dex"; return 1; }

    if ! java -jar "${tools_dir}/apktool.jar" d -q -r -f "$payload_work/payload.jar" -o "$payload_work/smali_out"; then
        err "Failed to disassemble the Kaorios payload"
        return 1
    fi

    if [ ! -f "$payload_work/smali_out/smali/android/security/kaorios/KaoriosHook.smali" ]; then
        err "Payload does not contain android.security.kaorios.KaoriosHook - wrong classes.dex?"
        return 1
    fi

    KAORIOS_PAYLOAD_SMALI="$payload_work/smali_out"
    log "✓ Kaorios payload ready ($(cat "${KAORIOS_ASSET_DIR}/payload/version.txt" 2>/dev/null || echo unknown), sha256 ${actual:0:12}…)"
    return 0
}

# Old Kaorios patch (V1.x / 2.0.4.0) found? Remove it first (fail-closed), so the new hooks go on a clean tree.
kaorios_check_stock() {
    local decompile_dir="$1"
    local remover="${_KAORIOS_SELF_DIR}/kaorios_remove_legacy.py"
    local rc=0

    python3 -I "$remover" "$decompile_dir" --check >/dev/null 2>&1 || rc=$?
    if [ "$rc" -eq 0 ]; then
        return 0
    elif [ "$rc" -eq 10 ]; then
        warn "An OLD Kaorios patch (V1.x / 2.0.4.0) is present in this jar - removing it before applying 2.0.6.x"
        if ! python3 -I "$remover" "$decompile_dir" >&2; then
            err "Could not cleanly remove the old Kaorios patch. Use the stock jar of your ROM instead."
            return 1
        fi
        return 0
    fi
    err "Legacy Kaorios check failed (exit $rc)"
    return 1
}

# Run the official patcher on a decompiled smali tree.
kaorios_run_patcher() {
    local decompile_dir="$1"
    local android_version="$2"

    case "$android_version" in
        13|14|15|16|17) ;;
        *) err "Kaorios: unsupported Android version '$android_version' (use 13-17)"; return 1 ;;
    esac

    if ! python3 -I "$KAORIOS_PATCHER" "$decompile_dir" \
            --android-version "$android_version" --mode 1 --no-delay \
            --payload-smali "$KAORIOS_PAYLOAD_SMALI" >&2; then
        err "The Kaorios patcher refused this jar (see messages above)."
        err "It fails closed on layouts it does not recognise - nothing was half-applied by it."
        return 1
    fi
    return 0
}

# Verify the saved smali tree against the payload ABI (hard failure on a missing callee).
kaorios_verify_abi() {
    local decompile_dir="$1"
    if ! python3 -I "$KAORIOS_VERIFY_ABI" "$decompile_dir" --payload-smali "$KAORIOS_PAYLOAD_SMALI" >&2; then
        err "Payload ABI check failed: a hook calls a KaoriosHook method the payload does not provide."
        err "The APK/payload version and the patcher version do not match."
        return 1
    fi
    return 0
}

# framework.jar:  apply_kaorios_toolbox_patches <decompile_dir> <android_version>
apply_kaorios_toolbox_patches() {
    local decompile_dir="$1"
    local android_version="${2:-}"

    if [ -z "$android_version" ]; then
        err "apply_kaorios_toolbox_patches: Android version argument missing"
        return 1
    fi

    log "========================================="
    log "Applying Kaorios Toolbox patches to framework.jar (Android $android_version)"
    log "========================================="

    kaorios_prepare_payload || return 1
    kaorios_check_stock "$decompile_dir" || return 1

    python3 -I "${_KAORIOS_SELF_DIR}/kaorios_import_payload.py" "$decompile_dir" "$KAORIOS_PAYLOAD_SMALI" >&2 \
        || { err "Payload import failed"; return 1; }

    kaorios_run_patcher "$decompile_dir" "$android_version" || return 1
    kaorios_verify_abi "$decompile_dir" || return 1

    log "✓ Kaorios framework patches applied and verified"
    return 0
}

# services.jar:  apply_kaorios_services_patches <decompile_dir> <android_version>
apply_kaorios_services_patches() {
    local decompile_dir="$1"
    local android_version="${2:-}"

    if [ -z "$android_version" ]; then
        err "apply_kaorios_services_patches: Android version argument missing"
        return 1
    fi

    log "========================================="
    log "Applying Kaorios Toolbox patches to services.jar (Android $android_version)"
    log "========================================="

    kaorios_prepare_payload || return 1
    kaorios_check_stock "$decompile_dir" || return 1
    kaorios_run_patcher "$decompile_dir" "$android_version" || return 1
    kaorios_verify_abi "$decompile_dir" || return 1

    log "✓ Kaorios services patches applied and verified"
    return 0
}
