#!/usr/bin/env bash
# update_kaorios.sh - sync a Kaorios Toolbox 2.0.6.x release into this repo (OFFLINE, no downloads)
#
# What it updates:
#   kaorios_toolbox/payload/classes.dex (+ .sha256, version.txt)   <- the framework payload
#   kaorios_toolbox/patcher/*                                      <- official patcher scripts (copied unchanged)
#   kaorios_toolbox/KaoriosToolbox.apk, privapp XML, version.txt   <- only if you pass --apk / --xml
#
# Usage:
#   ./scripts/update_kaorios.sh --repo /path/to/Kaorios-Toolbox-main \
#                               --dex  /path/to/classes.dex \
#                               --version 2.0.6.3 \
#                               [--sha256sums /path/to/SHA256SUMS] \
#                               [--apk /path/to/KaoriosToolbox.apk] [--xml /path/to/privapp_whitelist_com.kousei.kaorios.xml]
#
# --repo : an extracted checkout/zip of github.com/hzzmonetvn/Kaorios-Toolbox from the SAME release as --dex
# --dex  : classes.dex attached to that release
# Always take the dex, the patcher scripts and the APK from the SAME release.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
KAORIOS_DIR="$PROJECT_ROOT/kaorios_toolbox"

REPO="" DEX="" VERSION="" SUMS="" APK="" XML=""
while [ $# -gt 0 ]; do
    case "$1" in
        --repo) REPO="$2"; shift 2 ;;
        --dex) DEX="$2"; shift 2 ;;
        --version) VERSION="$2"; shift 2 ;;
        --sha256sums) SUMS="$2"; shift 2 ;;
        --apk) APK="$2"; shift 2 ;;
        --xml) XML="$2"; shift 2 ;;
        -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
        *) echo "Unknown option: $1" >&2; exit 1 ;;
    esac
done

die() { echo "[ERROR] $*" >&2; exit 1; }
info() { echo "[INFO] $*"; }

[ -n "$REPO" ] && [ -n "$DEX" ] && [ -n "$VERSION" ] || die "--repo, --dex and --version are required (see --help)"
[ -d "$REPO/script" ] || die "No script/ folder in $REPO - point --repo at the extracted Kaorios-Toolbox repo root"
[ -f "$REPO/script/kaorios_patcher.py" ] || die "$REPO/script/kaorios_patcher.py not found"
[ -f "$DEX" ] || die "classes.dex not found: $DEX"

actual="$(sha256sum "$DEX" | awk '{print $1}')"
if [ -n "$SUMS" ]; then
    [ -f "$SUMS" ] || die "SHA256SUMS not found: $SUMS"
    expected="$(grep -E '(^|[[:space:]*])classes\.dex$' "$SUMS" | awk '{print $1}' | head -n1)"
    [ -n "$expected" ] || die "No classes.dex entry in $SUMS"
    [ "$expected" = "$actual" ] || die "classes.dex checksum mismatch: manifest $expected, file $actual"
    info "classes.dex matches SHA256SUMS"
else
    echo "[WARN] No --sha256sums given: compare this hash with the release SHA256SUMS yourself:"
    echo "       $actual"
fi

# The payload must really be a Kaorios framework payload
grep -aq "Landroid/security/kaorios/KaoriosHook;" "$DEX" || die "classes.dex has no android.security.kaorios.KaoriosHook class - wrong file?"

backup="$KAORIOS_DIR.backup.$(date +%Y%m%d_%H%M%S)"
if [ -d "$KAORIOS_DIR" ]; then
    info "Backing up current kaorios_toolbox -> $backup"
    cp -r "$KAORIOS_DIR" "$backup"
fi

mkdir -p "$KAORIOS_DIR/payload" "$KAORIOS_DIR/patcher"

info "Updating payload ($VERSION)"
cp "$DEX" "$KAORIOS_DIR/payload/classes.dex"
(cd "$KAORIOS_DIR/payload" && sha256sum classes.dex > classes.dex.sha256)
printf '%s\n' "${VERSION#[Vv]}" > "$KAORIOS_DIR/payload/version.txt"

info "Updating official patcher scripts"
rm -rf "$KAORIOS_DIR/patcher"
mkdir -p "$KAORIOS_DIR/patcher"
find "$REPO/script" -maxdepth 1 -type f \
    ! -name 'test_*' ! -name 'bionic_fakelock_patcher.py' ! -name 'validate_keybox.py' \
    ! -name 'publish-verified-artifact.py' ! -name 'check-advanced-policy-sepolicy.*' \
    -exec cp {} "$KAORIOS_DIR/patcher/" \;

if [ -n "$APK" ]; then
    [ -f "$APK" ] || die "APK not found: $APK"
    info "Updating KaoriosToolbox.apk"
    cp "$APK" "$KAORIOS_DIR/KaoriosToolbox.apk"
    printf '%s\n' "$VERSION" > "$KAORIOS_DIR/version.txt"
fi
if [ -n "$XML" ]; then
    [ -f "$XML" ] || die "XML not found: $XML"
    cp "$XML" "$KAORIOS_DIR/privapp_whitelist_com.kousei.kaorios.xml"
fi

info "Done. Payload sha256: $actual"
[ -z "$APK" ] && echo "[WARN] APK not updated: make sure KaoriosToolbox.apk is from the $VERSION release too (module builds only)."
info "Backup of the previous state: $backup"
