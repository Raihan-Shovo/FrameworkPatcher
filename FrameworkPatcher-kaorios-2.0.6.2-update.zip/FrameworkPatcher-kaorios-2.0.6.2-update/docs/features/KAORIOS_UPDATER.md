# Kaorios Toolbox 2.0.6.x integration

This repo patches **Kaorios Toolbox 2.0.6.x** into `framework.jar` and `services.jar` using the
**official Kaorios patcher** (vendored unchanged) plus the release's framework payload (`classes.dex`).

> The old V1.x approach (copying `com/android/internal/util/kaorios/*` smali classes) and the
> 2.0.4.0-era hooks are **gone**. If your `framework.jar` still carries that old patch (e.g. it came out of a
> ROM you built earlier), it is **removed automatically** first (`scripts/core/kaorios_remove_legacy.py`,
> fail-closed). A stock jar is still the cleanest starting point.

## Just give it the jars

Put the `framework.jar` and `services.jar` of your ROM in the repo root, then run
(example: Android 15):

```bash
./scripts/patcher_a15.sh 35 mydevice 1.0.0 --framework --services --kaorios-toolbox
```

Result: `framework_patched.jar` and `services_patched.jar` (plus a module zip you can ignore if you bake the
jars into a ROM). `--kaorios-toolbox` needs **both** jars; the script refuses a framework-only run.
Use `patcher_a13.sh` / `a14.sh` / `a16.sh` with API 33 / 34 / 36 for other Android versions.

The run **stops with an error** (no half-patched jar) if:
- an old Kaorios patch is present but is not a variant the remover recognises (use stock jars),
- the official patcher does not recognise a class layout on your ROM (it fails closed),
- a hook calls a `KaoriosHook` method that the payload does not contain (version mismatch).

## What gets patched

| Jar | Class | Hook |
|---|---|---|
| framework.jar | `Instrumentation` (2 `newApplication`) | `KaoriosHook.initContext` |
| framework.jar | `ActivityThread.handleBindApplication` | `KaoriosHook.initActivityThread` |
| framework.jar | `Settings$NameValueCache.getStringForUser` | `shouldHideDevStatusFromNameValueCache` |
| framework.jar | `ApplicationPackageManager.hasSystemFeature` | `KaoriosHook.hasSystemFeature` |
| framework.jar | `AndroidKeyStoreKeyPairGeneratorSpi.generateKeyPair` | `initGenerateSoftwareKeyPair` |
| framework.jar | `AndroidKeyStoreSpi.engineGetCertificateChain` | `CertificateChainIfNeeded` |
| services.jar | `SystemServer.run` | `initSystemServer` |
| services.jar | `ComputerEngine` | `shouldHideAppListForCaller`, `filterInstallerPackageName` |

The payload classes (`android.security.kaorios.*`, `com.kousei.framework.*`) are imported **class-wise** into
`framework.jar`: an existing class with the same name is replaced where it lives, new classes go into their own new
DEX split, unrelated OEM classes are never touched.

Not automated here (manual, see the Kaorios `Toolbox-docs/2.0.6+` guides): SettingsProvider/CorePatch changes,
Disable Secure Flag, Android 17 `Build` spoof.

## Files

```
kaorios_toolbox/payload/    classes.dex  classes.dex.sha256  version.txt   <- framework payload (release asset)
kaorios_toolbox/patcher/    official Kaorios patcher scripts (unchanged copy of Kaorios-Toolbox/script/)
kaorios_toolbox/KaoriosToolbox.apk + privapp xml + version.txt             <- app, only used when building the module
scripts/core/kaorios_patches.sh         glue: payload prepare/import -> official patcher -> ABI verify
scripts/core/kaorios_import_payload.py  class-wise payload import (new classes go to a fresh DEX split)
scripts/core/kaorios_remove_legacy.py   removes the old V1.x / 2.0.4.0 Kaorios patch from a framework tree
scripts/update_kaorios.sh               sync a new Kaorios release into the repo (offline)
```

## Updating to a newer Kaorios release

Download from the release: `classes.dex`, `SHA256SUMS` and the APK, and download the repo source of the **same**
release. Then:

```bash
./scripts/update_kaorios.sh --repo /path/to/Kaorios-Toolbox-main --dex /path/to/classes.dex \
    --version 2.0.6.3 --sha256sums /path/to/SHA256SUMS --apk /path/to/KaoriosToolbox.apk
```

It checks the dex against `SHA256SUMS`, makes a backup, and copies payload + patcher scripts. Always keep the
payload, the patcher scripts and the app on the **same** version.

## Notes

- Payload in this repo: Kaorios `2.0.6.2`, `classes.dex` sha256 `7fa7835bbc3c4bc4decc54f179ee21a471c6ef4aa4ce5c1de50686cc4448fffa`
  (compare with the release `SHA256SUMS`).
- The bundled `kaorios_toolbox/KaoriosToolbox.apk` may be an older version. It is only used for module builds, and
  `create_module` warns when it differs from the payload version.
- The patcher scripts are Kaorios' work (see Kaorios-Toolbox README credits); keep them unmodified so updates stay a plain copy.
- Host checks cannot prove boot or runtime behaviour: test on a device.
